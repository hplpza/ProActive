package com.example.proactive;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class userLogin extends AppCompatActivity {
    EditText txtName,  txtPassword;
    Button btnLogin, btnRegister;
    FirebaseAuth fAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);



        txtName = findViewById(R.id.fieldUsername);
        txtPassword = findViewById(R.id.fieldPassword);
        btnLogin = findViewById(R.id.btnLog);
        btnRegister = findViewById(R.id.btnReg);
        fAuth = FirebaseAuth.getInstance();




        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = txtName.getText().toString().trim();
                String password = txtPassword.getText().toString().trim();


                if (TextUtils.isEmpty(username)) {
                    txtName.setError("Name is Required.");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    txtPassword.setError("Password is Required.");
                    return;
                }
                if (password.length() <= 6) {
                    txtPassword.setError("Password too short.");
                    return;
                }


                //authenticate
try
{
    fAuth.signInWithEmailAndPassword(username, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
        @Override
        public void onComplete(@NonNull Task<AuthResult> task) {
            if (task.isSuccessful())
            {
                Toast.makeText(userLogin.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                Intent loginIntent = new Intent(userLogin.this, FragmentContainer.class);
                startActivity(loginIntent);


            } else {
                Toast.makeText(userLogin.this, "Error!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    });
}
catch (Exception e)
{
    Toast.makeText(userLogin.this, "Error!", Toast.LENGTH_SHORT).show();
    fAuth.getInstance().signOut();
    finish();
}




            }
        });
    }




    public void buttonClick(View v) {
        switch(v.getId()) {
            case R.id.btnReg:

                Intent registerIntent = new Intent(userLogin.this, RegisterActivity.class);
                startActivity(registerIntent);
                break;

        }
    }
}