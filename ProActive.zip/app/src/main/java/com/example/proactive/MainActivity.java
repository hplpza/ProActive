package com.example.proactive;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    long Delay = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Timer RunSplash = new Timer();

        TimerTask splashActivity = new TimerTask() {
            @Override
            public void run() {
                finish();

                Intent firstIntent = new Intent(MainActivity.this, userLogin.class);
                startActivity(firstIntent);
            }

        };
        //Start the timer

        RunSplash.schedule(splashActivity, Delay);

    }






    //

    //

}