package com.example.proactive;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {
    long Delay = 3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Timer RunSplash = new Timer();

        TimerTask splashActivity = new TimerTask() {
            @Override
            public void run() {
                finish();

                Intent firstIntent = new Intent(SplashActivity.this, userLogin.class);
                startActivity(firstIntent);
            }

        };

        RunSplash.schedule(splashActivity, Delay);
    }
}