package com.example.proactive;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
EditText txtName,  txtPassword, txtConfirmPassword;
Button btnLogin, btnRegister;
FirebaseAuth fAuth;
ProgressBar progressbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        txtName = findViewById(R.id.fieldUsername2);
        txtPassword = findViewById(R.id.fieldPassword2);
        txtConfirmPassword = findViewById(R.id.fieldConfirm2);
        btnLogin = findViewById(R.id.btnLog2);
        btnRegister = findViewById(R.id.btnReg2);
        fAuth = FirebaseAuth.getInstance();



       if(fAuth.getCurrentUser() != null)
        {
            Intent skipLogin = new Intent(RegisterActivity.this, FragmentContainer.class);
            startActivity(skipLogin);
        }

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = txtName.getText().toString().trim();
                String password = txtPassword.getText().toString().trim();


                if(TextUtils.isEmpty(username))
                {
                    txtName.setError("Name is Required.");
                    return;
                }
                if(TextUtils.isEmpty(password))
                {
                    txtPassword.setError("Password is Required.");
                    return;
                }
                if(password.length() <= 6)
                {
                    txtPassword.setError("Password is Required.");
                    return;
                }



                //register user
                fAuth.createUserWithEmailAndPassword(username, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(RegisterActivity.this, "User Created!", Toast.LENGTH_SHORT).show();
                            Intent loginIntent = new Intent(RegisterActivity.this, FragmentContainer.class);
                            startActivity(loginIntent);


                        }
                        else
                        {
                            Toast.makeText(RegisterActivity.this, "Error!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });



            }

        });
//
    }

    public void buttonClick(View v) {
        switch(v.getId()) {
            /*
            case R.id.btnReg2:

                Intent registerIntent = new Intent(RegisterActivity.this, RegisterActivity.class);
                startActivity(registerIntent);
                break;
*/
            case R.id.btnLog2:

                Intent loginIntent = new Intent(RegisterActivity.this, userLogin.class);
                startActivity(loginIntent);
                break;
        }
    }
}